<!-- PRODUCT SLIDER AREA START -->
<div class="ltn__product-slider-area ltn__product-gutter  pt-90 pb-40">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title-area text-center">
                        <h1 class="section-title section-title-border">top products</h1>
                    </div>
                </div>
            </div>
            <div class="row ltn__product-slider-item-four-active slick-arrow-1">
                <!-- ltn__product-item -->
                <div class="col-12">
                    <div class="ltn__product-item text-center">
                        <div class="product-img">
                            <a href="gallery.php"><img src="img/product/9.jpg" alt="#"></a>
                            <div class="product-badge">
                                <ul>
                                    <li class="badge-2">10%</li>
                                </ul>
                            </div>
                            <div class="product-hover-action product-hover-action-2">
                                
                            </div>
                        </div>
                        <div class="product-info">
                            <h2 class="product-title"><a href="gallery.php">Pink Flower Tree</a></h2>
                            <div class="product-price">
                                
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ltn__product-item -->
                <div class="col-12">
                    <div class="ltn__product-item text-center">
                        <div class="product-img">
                            <a href="gallery.php"><img src="img/product/10.jpg" alt="#"></a>
                            <div class="product-badge">
                                <ul>
                                    <li class="badge-1">Hot</li>
                                </ul>
                            </div>
                            <div class="product-hover-action product-hover-action-2">
                                
                            </div>
                        </div>
                        <div class="product-info">
                            <h2 class="product-title"><a href="gallery.php">Premium Joyful</a></h2>
                            <div class="product-price">
                                
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ltn__product-item -->
                <div class="col-12">
                    <div class="ltn__product-item text-center">
                        <div class="product-img">
                            <a href="gallery.php"><img src="img/product/11.jpg" alt="#"></a>
                            <div class="product-badge">
                                <ul>
                                    <li class="badge-2">12%</li>
                                </ul>
                            </div>
                            <div class="product-hover-action product-hover-action-2">
                                
                            </div>
                        </div>
                        <div class="product-info">
                            <h2 class="product-title"><a href="gallery.php">The White Rose</a></h2>
                            <div class="product-price">
                                
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ltn__product-item -->
                <div class="col-12">
                    <div class="ltn__product-item text-center">
                        <div class="product-img">
                            <a href="gallery.php"><img src="img/product/12.jpg" alt="#"></a>
                            <div class="product-badge">
                                <ul>
                                    <li class="badge-1">Hot</li>
                                </ul>
                            </div>
                            <div class="product-hover-action product-hover-action-2">
                                
                            </div>
                        </div>
                        <div class="product-info">
                            <h2 class="product-title"><a href="gallery.php">Red Rose Bouquet</a></h2>
                            <div class="product-price">
                                
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ltn__product-item -->
                <div class="col-12">
                    <div class="ltn__product-item text-center">
                        <div class="product-img">
                            <a href="gallery.php"><img src="img/product/13.jpg" alt="#"></a>
                            <div class="product-badge">
                                <ul>
                                    <li class="badge-1">Hot</li>
                                </ul>
                            </div>
                            <div class="product-hover-action product-hover-action-2">
                                
                            </div>
                        </div>
                        <div class="product-info">
                            <h2 class="product-title"><a href="gallery.php">Heart's Desire</a></h2>
                            <div class="product-price">
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- PRODUCT SLIDER AREA END -->