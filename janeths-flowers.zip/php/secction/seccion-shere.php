    <!-- NEWSLETTER AREA START -->
    <div class="ltn__newsletter-area section-bg-1 bg-overlay-black-10 bg-image pt-110 pb-90  img_slayer" data-bs-bg="img/slider/slide1.jpg"  style="background-image: url(img/slider/slide1.jpg);">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="ltn__newsletter-inner ltn__newsletter-inner-4 text_foot text-center">
                        <h1>Get The Latest Deals</h1>
                        <h5>$30 coupon for first shopping</h5>
                        <form action="#" class="ltn__form-box">
                            <input type="email" name="email" placeholder="Email*">
                            <div class="btn-wrapper">
                                <button class="theme-btn-1 btn text-uppercase" type="submit">Subscribe</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- NEWSLETTER AREA END -->