<?php include('php/secction/header.php') ?>
<?php include('php/secction/slider.php') ?>
<?php include('php/secction/seccion-banner.php') ?>
<?php include('php/secction/seccion-product.php') ?>
<?php include('php/secction/seccion-banner2.php') ?>
<br><br><br><br><br><br><br><br><br>
<?php include('php/secction/seccion-cards.php') ?>
<?php include('php/secction/top-products.php') ?>
<?php include('php/secction/seccion-shere.php') ?>


<?php include('php/secction/footer.php') ?>
